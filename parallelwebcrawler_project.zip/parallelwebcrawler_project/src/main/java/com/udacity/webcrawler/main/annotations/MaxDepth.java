package com.udacity.webcrawler.main.annotations;

import com.google.inject.BindingAnnotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Qualifier for max depth binding. */
@BindingAnnotation
@Retention(RetentionPolicy.RUNTIME)
public @interface MaxDepth {}
