package com.udacity.webcrawler;

import com.udacity.webcrawler.parser.PageParser;
import com.udacity.webcrawler.parser.PageParserFactory;
import com.udacity.webcrawler.profile.ProfilingState;

import java.time.Clock;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Parallel crawler implementation.
 */
public final class ParallelWebCrawler implements WebCrawler {
    private final PageParserFactory parserFactory;
    private final int timeoutSeconds;
    private final int maxDepth;
    private final int popularWordCount;
    private final Clock clock;
    private final ProfilingState profilingState;
    private final int threads;

    public static class Builder {
        private PageParserFactory parserFactory;
        private int timeoutSeconds = 10;
        private int maxDepth = 1;
        private int popularWordCount = 10;
        private Clock clock = Clock.systemUTC();
        private ProfilingState profilingState = new ProfilingState();
        private int threads = Math.max(1, Runtime.getRuntime().availableProcessors());

        public Builder parserFactory(PageParserFactory f) { this.parserFactory = f; return this; }
        public Builder timeoutSeconds(int s) { this.timeoutSeconds = s; return this; }
        public Builder maxDepth(int d) { this.maxDepth = d; return this; }
        public Builder popularWordCount(int c) { this.popularWordCount = c; return this; }
        public Builder clock(Clock c) { this.clock = c; return this; }
        public Builder profilingState(ProfilingState p) { this.profilingState = p; return this; }
        public Builder threads(int t) { this.threads = t; return this; }
        public ParallelWebCrawler build() {
            if (parserFactory == null) throw new IllegalStateException("parserFactory required");
            return new ParallelWebCrawler(parserFactory, timeoutSeconds, maxDepth, popularWordCount, clock, profilingState, threads);
        }
    }

    public ParallelWebCrawler(PageParserFactory parserFactory, int timeoutSeconds, int maxDepth, int popularWordCount, Clock clock, ProfilingState profilingState, int threads) {
        this.parserFactory = parserFactory;
        this.timeoutSeconds = timeoutSeconds;
        this.maxDepth = maxDepth;
        this.popularWordCount = popularWordCount;
        this.clock = clock;
        this.profilingState = profilingState;
        this.threads = threads;
    }

    @Override
    public CrawlResult crawl(Collection<String> startPages) throws Exception {
        long startTime = clock.millis();
        ExecutorService executor = Executors.newFixedThreadPool(threads);
        ConcurrentMap<String, Boolean> visited = new ConcurrentHashMap<>();
        ConcurrentLinkedQueue<UrlDepth> queue = new ConcurrentLinkedQueue<>();
        AtomicInteger visitedCount = new AtomicInteger(0);
        ConcurrentMap<String,Integer> aggregateCounts = new ConcurrentHashMap<>();

        for (String s : startPages) {
            if (s == null || s.isBlank()) continue;
            if (visited.putIfAbsent(s, Boolean.TRUE) == null) {
                queue.add(new UrlDepth(s, 0));
            }
        }

        Runnable worker = () -> {
            while (true) {
                UrlDepth ud = queue.poll();
                if (ud == null) break;
                if (ud.depth > maxDepth) continue;
                try {
                    profilingState.start(ud.url);
                    PageParser parser = parserFactory.get(ud.url);
                    PageParser.Result r = parser.parse();
                    long duration = System.currentTimeMillis() - profilingState.startTime(ud.url);
                    profilingState.end(ud.url, duration);
                    visitedCount.incrementAndGet();

                    // aggregate words
                    r.wordCounts().forEach((k, v) ->
                            aggregateCounts.merge(k, v, Integer::sum)
                    );

                    // enqueue new links
                    if (ud.depth < maxDepth) {
                        for (String link : r.links()) {
                            if (link == null || link.isBlank()) continue;
                            if (visited.putIfAbsent(link, Boolean.TRUE) == null) {
                                queue.add(new UrlDepth(link, ud.depth + 1));
                            }
                        }
                    }
                } catch (Exception e) {
                    profilingState.end(ud.url, -1);
                }
            }
        };

        int workerCount = Math.max(1, threads);
        for (int i = 0; i < workerCount; i++) executor.submit(worker);

        executor.shutdown();
        boolean finished = executor.awaitTermination(timeoutSeconds, TimeUnit.SECONDS);
        if (!finished) executor.shutdownNow();

        long elapsed = clock.millis() - startTime;
        profilingState.recordSummary(visitedCount.get(), elapsed);

        CrawlResult.Builder b = CrawlResult.newBuilder()
                .setUrlsVisited(visitedCount.get())
                .setWordCounts(new TreeMap<>(aggregateCounts)); // deterministic ordering
        return b.build();
    }

    private static final class UrlDepth {
        final String url;
        final int depth;
        UrlDepth(String u, int d) { url = u; depth = d; }
    }
}
