package com.udacity.webcrawler.json;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.Reader;

public final class ConfigurationLoader {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public static CrawlerConfiguration read(Reader r) throws Exception {
        return MAPPER.readValue(r, CrawlerConfiguration.class);
    }
}
