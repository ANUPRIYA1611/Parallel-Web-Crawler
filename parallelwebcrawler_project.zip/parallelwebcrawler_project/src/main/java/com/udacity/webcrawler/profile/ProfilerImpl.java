package com.udacity.webcrawler.profile;

import javax.inject.Inject;
import java.lang.reflect.Proxy;
import java.time.Clock;
import java.util.Objects;

/**
 * Simple Profiler implementation returning dynamic proxies.
 */
public final class ProfilerImpl implements Profiler {

  private final Clock clock;
  private final ProfilingState state;

  @Inject
  public ProfilerImpl(Clock clock, ProfilingState state) {
    this.clock = Objects.requireNonNull(clock);
    this.state = Objects.requireNonNull(state);
  }

  @SuppressWarnings("unchecked")
  @Override
  public <T> T wrap(Class<T> clazz, T delegate) {
    Objects.requireNonNull(clazz);
    Objects.requireNonNull(delegate);
    ProfilingMethodInterceptor handler =
            new ProfilingMethodInterceptor(clock, state, delegate);

    return (T) Proxy.newProxyInstance(clazz.getClassLoader(), new Class<?>[]{clazz}, handler);
  }

  @Override
  public ProfilingState getState() {
    return state;
  }
}
