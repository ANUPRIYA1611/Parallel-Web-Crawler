package com.udacity.webcrawler.main;

import com.google.inject.AbstractModule;
import com.udacity.webcrawler.ParallelWebCrawler;
import com.udacity.webcrawler.WebCrawler;
import com.udacity.webcrawler.json.CrawlerConfiguration;
import com.udacity.webcrawler.parser.JsoupPageParser;
import com.udacity.webcrawler.parser.PageParserFactory;
import com.udacity.webcrawler.profile.ProfilingState;

public final class WebCrawlerModule extends AbstractModule {
    private final CrawlerConfiguration config;

    public WebCrawlerModule(CrawlerConfiguration config) { this.config = config; }

    @Override
    protected void configure() {
        bind(CrawlerConfiguration.class).toInstance(config);
        bind(WebCrawler.class).toProvider(() ->
                new ParallelWebCrawler.Builder()
                        .parserFactory(JsoupPageParser.factory())
                        .timeoutSeconds(config.getTimeoutSeconds())
                        .maxDepth(config.getMaxDepth())
                        .popularWordCount(config.getPopularWordCount())
                        .profilingState(new ProfilingState())
                        .threads(Runtime.getRuntime().availableProcessors())
                        .build()
        );
        bind(ProfilingState.class).toInstance(new ProfilingState());
    }
}
