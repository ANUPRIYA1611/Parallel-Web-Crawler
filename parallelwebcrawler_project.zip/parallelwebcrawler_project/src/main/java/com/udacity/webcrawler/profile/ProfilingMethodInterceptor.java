package com.udacity.webcrawler.profile;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.Clock;
import java.time.Instant;
import java.util.Objects;

/**
 * Measures execution time for methods annotated with @Profiled and records them
 * into ProfilingState.
 */
public final class ProfilingMethodInterceptor implements InvocationHandler {

  private final Clock clock;
  private final ProfilingState state;
  private final Object delegate;

  public ProfilingMethodInterceptor(Clock clock, ProfilingState state, Object delegate) {
    this.clock = Objects.requireNonNull(clock);
    this.state = Objects.requireNonNull(state);
    this.delegate = Objects.requireNonNull(delegate);
  }

  @Override
  public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
    boolean profiled = method.isAnnotationPresent(Profiled.class);
    if (!profiled) {
      try {
        return method.invoke(delegate, args);
      } catch (InvocationTargetException ite) {
        // unwrap original exception
        throw ite.getCause();
      }
    }

    Instant start = clock.instant();
    try {
      return method.invoke(delegate, args);
    } catch (InvocationTargetException ite) {
      // unwrap original exception thrown by the delegated method
      throw ite.getCause();
    } finally {
      Instant end = clock.instant();
      long millis = java.time.Duration.between(start, end).toMillis();
      // record method-level timing
      state.record(method.getDeclaringClass(), method, millis);
    }
  }
}
