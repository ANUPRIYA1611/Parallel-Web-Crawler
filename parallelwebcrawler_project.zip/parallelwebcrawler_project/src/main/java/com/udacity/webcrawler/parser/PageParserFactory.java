package com.udacity.webcrawler.parser;

/**
 * Factory for PageParser instances. Implement as a simple interface so tests
 * may provide deterministic stub implementations.
 */
public interface PageParserFactory {
    PageParser get(String url);
}
