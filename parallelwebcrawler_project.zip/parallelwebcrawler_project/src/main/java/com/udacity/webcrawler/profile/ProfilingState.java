package com.udacity.webcrawler.profile;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Method;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Profiling storage and dump.
 */
public final class ProfilingState {
    private final ConcurrentHashMap<String, Long> starts = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> durations = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Long> methodDurations = new ConcurrentHashMap<>();
    private final AtomicLong totalVisited = new AtomicLong(0);
    private final AtomicLong totalTime = new AtomicLong(0);

    public void start(String key) { starts.put(key, System.currentTimeMillis()); }

    public long startTime(String key) { return starts.getOrDefault(key, System.currentTimeMillis()); }

    public void end(String key, long durationMillis) {
        if (durationMillis >= 0) {
            durations.put(key, durationMillis);
            totalVisited.incrementAndGet();
            totalTime.addAndGet(durationMillis);
        }
    }

    public void recordSummary(long visitedCount, long elapsedMillis) {
        totalVisited.addAndGet(visitedCount);
        totalTime.addAndGet(elapsedMillis);
    }

    public void record(Class<?> clazz, Method method, long durationMillis) {
        if (clazz == null || method == null) return;
        String k = clazz.getName() + "#" + method.getName();
        methodDurations.merge(k, durationMillis, Long::sum);
    }

    public void dump(Writer out, Instant now) throws IOException {
        out.write("Profiling snapshot: " + now + "\n");
        out.write("Total visited: " + totalVisited.get() + "\n");
        out.write("Total time (ms): " + totalTime.get() + "\n");
        out.write("Per-URL durations:\n");
        for (Map.Entry<String, Long> e : durations.entrySet()) {
            out.write("  " + e.getKey() + " -> " + e.getValue() + "\n");
        }
        out.write("Per-method totals:\n");
        for (Map.Entry<String, Long> e : methodDurations.entrySet()) {
            out.write("  " + e.getKey() + " -> " + e.getValue() + "\n");
        }
        out.flush();
    }
}
