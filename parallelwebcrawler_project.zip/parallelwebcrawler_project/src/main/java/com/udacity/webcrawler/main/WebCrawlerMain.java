package com.udacity.webcrawler.main;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.udacity.webcrawler.CrawlResult;
import com.udacity.webcrawler.WebCrawler;
import com.udacity.webcrawler.json.ConfigurationLoader;
import com.udacity.webcrawler.json.CrawlResultWriter;
import com.udacity.webcrawler.json.CrawlerConfiguration;
import com.udacity.webcrawler.profile.ProfilingState;

import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;

public final class WebCrawlerMain {

    public static void main(String[] args) throws Exception {

        if (args.length == 0) {
            System.err.println("Please provide configuration file path.");
            System.exit(1);
        }

        Path configPath = Path.of(args[0]);
        if (!Files.exists(configPath)) {
            System.err.println("Config file not found: " + configPath);
            System.exit(1);
        }

        CrawlerConfiguration config;
        try (Reader reader = Files.newBufferedReader(configPath)) {
            config = ConfigurationLoader.read(reader);
        }

        Injector injector = Guice.createInjector(new WebCrawlerModule(config));
        WebCrawler crawler = injector.getInstance(WebCrawler.class);

        CrawlResult result = crawler.crawl(config.getStartPages());

        // Write JSON
        if (config.getResultPath() == null || config.getResultPath().isBlank()) {
            Writer out = new OutputStreamWriter(System.out);
            new CrawlResultWriter(result).write(out);
            out.flush();
        } else {
            new CrawlResultWriter(result).write(Path.of(config.getResultPath()));
        }

        // Profiling
        ProfilingState profiler = injector.getInstance(ProfilingState.class);
        Instant now = Instant.now(Clock.systemUTC());

        if (config.getProfileOutputPath() == null || config.getProfileOutputPath().isBlank()) {
            Writer out = new OutputStreamWriter(System.out);
            profiler.dump(out, now);
            out.flush();
        } else {
            try (Writer out = Files.newBufferedWriter(
                    Path.of(config.getProfileOutputPath()),
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND)) {
                profiler.dump(out, now);
            }
        }
    }
}
