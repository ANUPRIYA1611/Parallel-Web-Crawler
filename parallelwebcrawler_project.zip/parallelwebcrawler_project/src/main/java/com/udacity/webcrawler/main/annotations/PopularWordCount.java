package com.udacity.webcrawler.main.annotations;

import com.google.inject.BindingAnnotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Qualifier for popular word count binding. */
@BindingAnnotation
@Retention(RetentionPolicy.RUNTIME)
public @interface PopularWordCount {}
