package com.udacity.webcrawler.parser;

import java.util.List;
import java.util.Map;

/**
 * Parses a page and returns discovered links + word counts.
 */
public interface PageParser {

    record Result(List<String> links, Map<String, Integer> wordCounts) {}

    Result parse() throws Exception;
}
