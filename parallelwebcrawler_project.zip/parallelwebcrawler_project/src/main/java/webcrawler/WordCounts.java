package webcrawler;

import java.util.HashMap;
import java.util.Map;

/**
 * Mutable word count map helper.
 */
public final class WordCounts {
    private final Map<String, Integer> counts = new HashMap<>();

    public void increment(String word, int value) {
        counts.merge(word, value, Integer::sum);
    }

    public void merge(WordCounts other) {
        other.counts.forEach((k, v) -> counts.merge(k, v, Integer::sum));
    }

    public Map<String, Integer> asMap() {
        return counts;
    }
}
