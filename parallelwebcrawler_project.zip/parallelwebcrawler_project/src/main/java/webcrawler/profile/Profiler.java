package webcrawler.profile;

/**
 * Profiler that wraps delegate instances with proxies that record annotated methods.
 */
public interface Profiler {
  <T> T wrap(Class<T> clazz, T delegate);
  ProfilingState getState();
}
