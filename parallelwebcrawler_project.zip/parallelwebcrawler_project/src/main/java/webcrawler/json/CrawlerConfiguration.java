package webcrawler.json;

import java.util.List;

public class CrawlerConfiguration {
    private List<String> startPages;
    private int maxDepth = 1;
    private int timeoutSeconds = 10;
    private int popularWordCount = 10;
    private String resultPath;
    private String profileOutputPath;

    // Jackson requires no-arg constructor
    public CrawlerConfiguration() {}

    public List<String> getStartPages() { return startPages; }
    public void setStartPages(List<String> startPages) { this.startPages = startPages; }

    public int getMaxDepth() { return maxDepth; }
    public void setMaxDepth(int maxDepth) { this.maxDepth = maxDepth; }

    public int getTimeoutSeconds() { return timeoutSeconds; }
    public void setTimeoutSeconds(int timeoutSeconds) { this.timeoutSeconds = timeoutSeconds; }

    public int getPopularWordCount() { return popularWordCount; }
    public void setPopularWordCount(int popularWordCount) { this.popularWordCount = popularWordCount; }

    public String getResultPath() { return resultPath; }
    public void setResultPath(String resultPath) { this.resultPath = resultPath; }

    public String getProfileOutputPath() { return profileOutputPath; }
    public void setProfileOutputPath(String profileOutputPath) { this.profileOutputPath = profileOutputPath; }
}
