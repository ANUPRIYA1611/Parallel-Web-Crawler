package webcrawler.json;

import com.fasterxml.jackson.databind.ObjectMapper;
import webcrawler.CrawlResult;

import java.io.IOException;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class CrawlResultWriter {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private final CrawlResult result;

    public CrawlResultWriter(CrawlResult result) { this.result = result; }

    public void write(Writer writer) throws IOException {
        // do not close the writer here
        MAPPER.writerWithDefaultPrettyPrinter().writeValue(writer, result);
    }

    public void write(Path path) throws IOException {
        try (Writer w = Files.newBufferedWriter(path)) {
            write(w);
        }
    }
}
