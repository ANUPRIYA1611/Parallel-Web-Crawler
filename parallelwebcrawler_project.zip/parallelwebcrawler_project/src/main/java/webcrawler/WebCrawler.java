package webcrawler;

import java.util.Collection;

public interface WebCrawler {
    CrawlResult crawl(Collection<String> startPages) throws Exception;
}
