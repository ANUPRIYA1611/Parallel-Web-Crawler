package webcrawler.parser;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public final class JsoupPageParser implements PageParser {

    private final String url;
    private static final Pattern WORD = Pattern.compile("[a-zA-Z]+");

    public JsoupPageParser(String url) {
        this.url = Objects.requireNonNull(url);
    }

    @Override
    public Result parse() throws Exception {
        Document doc = Jsoup.connect(url)
                .userAgent("Mozilla/5.0")
                .timeout(5000)
                .get();

        Elements anchors = doc.select("a[href]");
        List<String> links = anchors.stream()
                .map(a -> a.attr("abs:href"))
                .filter(h -> h != null && !h.isBlank())
                .collect(Collectors.toList());

        String text = doc.body() == null ? "" : doc.body().text();

        Map<String, Integer> wc = new HashMap<>();
        Matcher m = WORD.matcher(text);
        while (m.find()) {
            String w = m.group().toLowerCase(Locale.ROOT);
            wc.merge(w, 1, Integer::sum);
        }

        return new Result(links, wc);
    }

    public static PageParserFactory factory() {
        return JsoupPageParser::new;
    }
}
