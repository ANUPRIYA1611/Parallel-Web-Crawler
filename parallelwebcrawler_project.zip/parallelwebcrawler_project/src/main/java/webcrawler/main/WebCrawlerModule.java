package webcrawler.main;

import com.google.inject.AbstractModule;
import webcrawler.ParallelWebCrawler;
import webcrawler.WebCrawler;
import webcrawler.json.CrawlerConfiguration;
import webcrawler.profile.ProfilingState;
import webcrawler.parser.PageParserFactory;
import webcrawler.parser.JsoupPageParser;

public final class WebCrawlerModule extends AbstractModule {
    private final CrawlerConfiguration config;

    public WebCrawlerModule(CrawlerConfiguration config) { this.config = config; }

    @Override
    protected void configure() {
        bind(CrawlerConfiguration.class).toInstance(config);
        bind(WebCrawler.class).toProvider(() ->
                new ParallelWebCrawler.Builder()
                        .parserFactory(JsoupPageParser.factory())
                        .timeoutSeconds(config.getTimeoutSeconds())
                        .maxDepth(config.getMaxDepth())
                        .popularWordCount(config.getPopularWordCount())
                        .profilingState(new ProfilingState())
                        .threads(Runtime.getRuntime().availableProcessors())
                        .build()
        );
        bind(ProfilingState.class).toInstance(new ProfilingState());
    }
}
