package webcrawler.main;

import com.google.inject.Guice;
import com.google.inject.Injector;
import webcrawler.CrawlResult;
import webcrawler.WebCrawler;
import webcrawler.json.ConfigurationLoader;
import webcrawler.json.CrawlResultWriter;
import webcrawler.json.CrawlerConfiguration;
import webcrawler.profile.ProfilingState;

import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.Clock;

public final class WebCrawlerMain {

    public static void main(String[] args) throws Exception {

        if (args.length == 0) {
            System.err.println("❌ Please provide configuration file path as argument");
            System.exit(1);
        }

        Path configPath = Path.of(args[0]);
        if (!Files.exists(configPath)) {
            System.err.println("❌ Configuration file not found: " + configPath);
            System.exit(1);
        }

        // ✅ Load configuration
        CrawlerConfiguration config;
        try (Reader reader = Files.newBufferedReader(configPath)) {
            config = ConfigurationLoader.read(reader);
        }

        // ✅ Inject dependencies
        Injector injector = Guice.createInjector(new WebCrawlerModule(config));
        WebCrawler crawler = injector.getInstance(WebCrawler.class);

        // ✅ Run crawler
        CrawlResult result = crawler.crawl(config.getStartPages());

        // ✅ Write result JSON
        if (config.getResultPath() == null || config.getResultPath().isBlank()) {
            // ✅ Do NOT close System.out
            Writer out = new OutputStreamWriter(System.out);
            new CrawlResultWriter(result).write(out);
            out.flush();
        } else {
            new CrawlResultWriter(result).write(Path.of(config.getResultPath()));
        }

        // ✅ Profiling output
        ProfilingState profiling = injector.getInstance(ProfilingState.class);
        Instant now = Instant.now(Clock.systemUTC());

        if (config.getProfileOutputPath() == null || config.getProfileOutputPath().isBlank()) {
            // ✅ Do NOT close System.out
            Writer out = new OutputStreamWriter(System.out);
            profiling.dump(out, now);
            out.flush();
        } else {
            try (Writer out = Files.newBufferedWriter(
                    Path.of(config.getProfileOutputPath()),
                    java.nio.file.StandardOpenOption.CREATE,
                    java.nio.file.StandardOpenOption.APPEND)) {
                profiling.dump(out, now);
            }
        }
    }
}
