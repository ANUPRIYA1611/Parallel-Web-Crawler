package webcrawler.main.annotations;

import com.google.inject.BindingAnnotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/** Qualifier for timeout binding. */
@BindingAnnotation
@Retention(RetentionPolicy.RUNTIME)
public @interface Timeout {}
