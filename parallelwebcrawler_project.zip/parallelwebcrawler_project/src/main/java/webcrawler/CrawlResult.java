package webcrawler;

import java.util.Collections;
import java.util.Map;

public final class CrawlResult {
    private final Map<String, Integer> wordCounts;
    private final int urlsVisited;

    private CrawlResult(Builder b) {
        this.wordCounts = Collections.unmodifiableMap(b.wordCounts);
        this.urlsVisited = b.urlsVisited;
    }

    public Map<String, Integer> getWordCounts() { return wordCounts; }
    public int getUrlsVisited() { return urlsVisited; }

    public static Builder newBuilder() { return new Builder(); }

    public static final class Builder {
        private Map<String, Integer> wordCounts = Map.of();
        private int urlsVisited = 0;

        public Builder setWordCounts(Map<String,Integer> m) { this.wordCounts = m; return this; }
        public Builder setUrlsVisited(int v) { this.urlsVisited = v; return this; }
        public CrawlResult build() { return new CrawlResult(this); }
    }
}
