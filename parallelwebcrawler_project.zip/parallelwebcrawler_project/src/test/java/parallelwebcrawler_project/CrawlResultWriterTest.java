package parallelwebcrawler_project;

import org.junit.jupiter.api.Test;

import com.udacity.webcrawler.CrawlResult;
import com.udacity.webcrawler.json.CrawlResultWriter;

import java.io.StringWriter;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class CrawlResultWriterTest {
    @Test
    void writesResultToWriter() throws Exception {
        var result = CrawlResult.newBuilder()
                .setUrlsVisited(2)
                .setWordCounts(Map.of("hello", 3))
                .build();
        StringWriter sw = new StringWriter();
        new CrawlResultWriter(result).write(sw);
        String out = sw.toString();
        assertTrue(out.contains("urlsVisited"));
        assertTrue(out.contains("hello"));
    }
}
