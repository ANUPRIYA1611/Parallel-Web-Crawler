package parallelwebcrawler_project;

import org.junit.jupiter.api.Test;

import com.udacity.webcrawler.json.ConfigurationLoader;
import com.udacity.webcrawler.json.CrawlerConfiguration;

import java.io.StringReader;

import static org.junit.jupiter.api.Assertions.*;

class ConfigurationLoaderTest {
    @Test
    void loadsConfigFromJsonString() throws Exception {
        String json = """
            {
              "startPages": ["http://example.com/"],
              "maxDepth": 1,
              "timeoutSeconds": 2,
              "popularWordCount": 5,
              "resultPath": "out.json",
              "profileOutputPath": "profile.txt"
            }
            """;
        CrawlerConfiguration c = ConfigurationLoader.read(new StringReader(json));
        assertNotNull(c);
        assertEquals(1, c.getStartPages().size());
        assertEquals(2, c.getTimeoutSeconds());
        assertEquals("out.json", c.getResultPath());
    }
}
