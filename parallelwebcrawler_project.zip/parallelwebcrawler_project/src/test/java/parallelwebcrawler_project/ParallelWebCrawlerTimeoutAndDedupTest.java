package parallelwebcrawler_project;

import org.junit.jupiter.api.Test;

import com.udacity.webcrawler.CrawlResult;
import com.udacity.webcrawler.ParallelWebCrawler;
import com.udacity.webcrawler.parser.PageParser;
import com.udacity.webcrawler.parser.PageParserFactory;
import com.udacity.webcrawler.profile.ProfilingState;

import java.time.Clock;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;

class ParallelWebCrawlerTimeoutAndDedupTest {
    @Test
    void enforcesTimeoutAndDoesNotDoubleVisit() throws Exception {
        AtomicInteger calls = new AtomicInteger(0);

        PageParserFactory factory = url -> (PageParser) () -> {
            calls.incrementAndGet();
            // deterministic: no links, simple wordcounts
            return new PageParser.Result(Collections.emptyList(), Map.of("x", 1));
        };

        ParallelWebCrawler crawler = new ParallelWebCrawler.Builder()
                .parserFactory(factory)
                .timeoutSeconds(1)
                .maxDepth(2)
                .profilingState(new ProfilingState())
                .clock(Clock.systemUTC())
                .threads(2)
                .build();

        CrawlResult result = crawler.crawl(List.of("http://example.com/self"));
        assertNotNull(result);
        assertTrue(calls.get() > 0);
        assertTrue(calls.get() <= Math.max(1, result.getUrlsVisited() + 5));
    }
}




